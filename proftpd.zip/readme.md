
------------------------------------------
PROFTPD AND LDAP MADE EASY
------------------------------------------

Install:

run proftpd.me with sudo

Remove:

run proftpd.remove.me with sudo